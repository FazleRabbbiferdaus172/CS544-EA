package application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab12part1Application {

	public static void main(String[] args) {
		SpringApplication.run(Lab12part1Application.class, args);
	}

}
