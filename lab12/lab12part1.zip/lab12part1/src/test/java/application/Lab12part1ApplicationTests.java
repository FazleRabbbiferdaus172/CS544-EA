package application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab12part1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
